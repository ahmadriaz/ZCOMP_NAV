sap.ui.controller("tcs.cl.Comp.controller.ProductList", {

gotoDetail : function(){
	this.getOwnerComponent().getRouter().navTo("pdetail");
}

});