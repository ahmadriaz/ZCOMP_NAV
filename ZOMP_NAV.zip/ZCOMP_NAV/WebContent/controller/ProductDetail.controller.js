sap.ui.controller("tcs.cl.Comp.controller.ProductDetail", {

	goBack : function(){
		this.getOwnerComponent().getRouter().navTo("plist");
	}

});